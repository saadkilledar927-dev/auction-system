# Online Auction System (C++ Mini Project — Static Members Case Study)

A console-based C++ mini project simulating an online auction house.
Demonstrates OOP concepts with a strong focus on **static data members**
and **static member functions**.

## Problem Statement
Design a system where multiple items can be listed for auction, multiple
bidders can place bids, and the system tracks running totals (items listed,
bidders registered, auctions conducted, highest bid overall) using static
class members — shared across all objects of a class rather than stored
per-object.

## Classes (5)

| Class            | Responsibility                                              | Static Members |
|-------------------|--------------------------------------------------------------|-----------------|
| `Item`            | Represents an auction item (id, name, base price, current bid) | `static int itemCount` |
| `Bidder`          | Represents a registered bidder (id, name)                    | `static int bidderCount` |
| `Auction`         | Runs the bidding process for one `Item`, tracks the winner   | `static int auctionCount`, `static float highestBidOverall` |
| `AuctionManager`  | Holds and manages multiple `Auction` objects, prints summary | `static int totalManagedAuctions` |
| `main.cpp` (driver)| Demonstrates object creation and interaction between classes | — |

## Key OOP / Static Concepts Demonstrated
- **Static data members** shared across all objects of a class (e.g. `itemCount` increments every time any `Item` is created).
- **Static member functions** (`Item::getItemCount()`) callable without an object.
- **Class composition** — `Auction` "has-a" `Item` and a `Bidder`.
- **Encapsulation** — private data accessed only through public getters/setters.
- **Aggregation** — `AuctionManager` manages a collection of `Auction` objects.

## Project Structure
```
auction-system/
├── src/
│   ├── Item.h / Item.cpp
│   ├── Bidder.h / Bidder.cpp
│   ├── Auction.h / Auction.cpp
│   ├── AuctionManager.h / AuctionManager.cpp
│   └── main.cpp
├── README.md
└── .gitignore
```

## How to Build & Run

```bash
cd src
g++ -std=c++17 -o auction_system main.cpp Item.cpp Bidder.cpp Auction.cpp AuctionManager.cpp
./auction_system
```

## Sample Output
```
===== ONLINE AUCTION SYSTEM (Static Members Demo) =====

Aarav placed a new highest bid of 5500 on Vintage Painting
Meera placed a new highest bid of 6000 on Vintage Painting
Kabir's bid of 5800 is too low. Current highest bid is 6000
...
===== AUCTION HOUSE SUMMARY =====
Total Items Listed   : 2
Total Bidders        : 5
Total Auctions Run   : 2
Highest Bid Overall  : 9000
Auctions Under Mgr   : 2
==================================
```

> Note: `Total Bidders` counts every `Bidder` **object construction**,
> including internal ones (e.g. the placeholder "No Bid Yet" bidder
> created inside each `Auction`). This is a good discussion point in a
> viva about pass-by-value vs pass-by-reference and static counters.

## Possible Extensions
- Replace pass-by-value with pass-by-reference/pointers to avoid extra constructions.
- Add a `Report` class for exporting results to a file.
- Add auction time limits using `<chrono>`.
- Add inheritance: `SealedBidAuction` and `OpenBidAuction` as subclasses of `Auction`.
