#include "Item.h"
#include <iostream>
using namespace std;

int Item::itemCount = 0;   // static member initialization

Item::Item(string name, float basePrice) {
    itemCount++;
    itemId = itemCount;
    itemName = name;
    this->basePrice = basePrice;
    currentBid = basePrice;
}

int Item::getItemId() const { return itemId; }
string Item::getItemName() const { return itemName; }
float Item::getBasePrice() const { return basePrice; }
float Item::getCurrentBid() const { return currentBid; }
void Item::setCurrentBid(float bid) { currentBid = bid; }

int Item::getItemCount() { return itemCount; }

void Item::display() const {
    cout << "Item ID: " << itemId
         << " | Name: " << itemName
         << " | Base Price: " << basePrice
         << " | Current Bid: " << currentBid << endl;
}
