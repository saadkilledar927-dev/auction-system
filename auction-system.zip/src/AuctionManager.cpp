#include "AuctionManager.h"
#include "Item.h"
#include "Bidder.h"
#include <iostream>
using namespace std;

int AuctionManager::totalManagedAuctions = 0;

AuctionManager::AuctionManager() {}

void AuctionManager::addAuction(Auction a) {
    auctions.push_back(a);
    totalManagedAuctions++;
}

void AuctionManager::showAllAuctions() const {
    cout << "\n--- All Auctions ---\n";
    for (const auto &a : auctions) {
        a.display();
    }
}

void AuctionManager::closeAll() {
    for (auto &a : auctions) {
        a.closeAuction();
    }
}

int AuctionManager::getTotalManagedAuctions() { return totalManagedAuctions; }

void AuctionManager::showSummary() {
    cout << "\n===== AUCTION HOUSE SUMMARY =====\n";
    cout << "Total Items Listed   : " << Item::getItemCount() << endl;
    cout << "Total Bidders        : " << Bidder::getBidderCount() << endl;
    cout << "Total Auctions Run   : " << Auction::getAuctionCount() << endl;
    cout << "Highest Bid Overall  : " << Auction::getHighestBidOverall() << endl;
    cout << "Auctions Under Mgr   : " << totalManagedAuctions << endl;
    cout << "==================================\n";
}
