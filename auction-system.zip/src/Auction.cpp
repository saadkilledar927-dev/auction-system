#include "Auction.h"
#include <iostream>
using namespace std;

int Auction::auctionCount = 0;
float Auction::highestBidOverall = 0.0f;

Auction::Auction(Item auctionItem)
    : item(auctionItem), winningBidder("No Bid Yet") {
    auctionCount++;
    auctionId = auctionCount;
    finalPrice = auctionItem.getBasePrice();
    completed = false;
}

void Auction::placeBid(Bidder bidder, float bidAmount) {
    if (completed) {
        cout << "Auction #" << auctionId << " is already closed.\n";
        return;
    }
    if (bidAmount > item.getCurrentBid()) {
        item.setCurrentBid(bidAmount);
        winningBidder = bidder;
        finalPrice = bidAmount;

        if (bidAmount > highestBidOverall) {
            highestBidOverall = bidAmount;   // update static tracker
        }
        cout << bidder.getBidderName() << " placed a new highest bid of "
             << bidAmount << " on " << item.getItemName() << endl;
    } else {
        cout << bidder.getBidderName() << "'s bid of " << bidAmount
             << " is too low. Current highest bid is "
             << item.getCurrentBid() << endl;
    }
}

void Auction::closeAuction() {
    completed = true;
    cout << "\nAuction #" << auctionId << " closed. Item '"
         << item.getItemName() << "' sold to "
         << winningBidder.getBidderName() << " for " << finalPrice << endl;
}

void Auction::display() const {
    cout << "Auction #" << auctionId << " | Item: " << item.getItemName()
         << " | Current Highest Bid: " << item.getCurrentBid()
         << " | Leading Bidder: " << winningBidder.getBidderName() << endl;
}

int Auction::getAuctionCount() { return auctionCount; }
float Auction::getHighestBidOverall() { return highestBidOverall; }
