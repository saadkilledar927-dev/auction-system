#include "Bidder.h"
#include <iostream>
using namespace std;

int Bidder::bidderCount = 0;

Bidder::Bidder(string name) {
    bidderCount++;
    bidderId = bidderCount;
    bidderName = name;
}

int Bidder::getBidderId() const { return bidderId; }
string Bidder::getBidderName() const { return bidderName; }

int Bidder::getBidderCount() { return bidderCount; }

void Bidder::display() const {
    cout << "Bidder ID: " << bidderId << " | Name: " << bidderName << endl;
}
