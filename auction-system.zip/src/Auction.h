#ifndef AUCTION_H
#define AUCTION_H

#include "Item.h"
#include "Bidder.h"
#include <string>
using namespace std;

class Auction {
private:
    int auctionId;
    Item item;
    Bidder winningBidder;
    float finalPrice;
    bool completed;

    static int auctionCount;         // total auctions created
    static float highestBidOverall;  // highest bid seen across ALL auctions

public:
    Auction(Item auctionItem);

    void placeBid(Bidder bidder, float bidAmount);
    void closeAuction();
    void display() const;

    static int getAuctionCount();
    static float getHighestBidOverall();
};

#endif
