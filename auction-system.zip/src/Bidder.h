#ifndef BIDDER_H
#define BIDDER_H

#include <string>
using namespace std;

class Bidder {
private:
    int bidderId;
    string bidderName;

    static int bidderCount;   // shared across all Bidder objects

public:
    Bidder(string name);

    int getBidderId() const;
    string getBidderName() const;

    static int getBidderCount();
    void display() const;
};

#endif
