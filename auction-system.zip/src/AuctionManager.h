#ifndef AUCTION_MANAGER_H
#define AUCTION_MANAGER_H

#include "Auction.h"
#include <vector>
using namespace std;

class AuctionManager {
private:
    vector<Auction> auctions;
    static int totalManagedAuctions;   // static tracker for the manager

public:
    AuctionManager();

    void addAuction(Auction a);
    void showAllAuctions() const;
    void closeAll();

    static int getTotalManagedAuctions();
    static void showSummary();   // uses statics from Item, Bidder, Auction
};

#endif
