#include "Item.h"
#include "Bidder.h"
#include "Auction.h"
#include "AuctionManager.h"
#include <iostream>
using namespace std;

int main() {
    cout << "===== ONLINE AUCTION SYSTEM (Static Members Demo) =====\n\n";

    // Create items
    Item painting("Vintage Painting", 5000);
    Item watch("Antique Watch", 8000);

    // Create bidders
    Bidder b1("Aarav");
    Bidder b2("Meera");
    Bidder b3("Kabir");

    // Create auctions
    Auction auction1(painting);
    Auction auction2(watch);

    // Bidding on auction 1
    auction1.placeBid(b1, 5500);
    auction1.placeBid(b2, 6000);
    auction1.placeBid(b3, 5800);   // too low, rejected

    // Bidding on auction 2
    auction2.placeBid(b2, 8200);
    auction2.placeBid(b3, 9000);

    // Manage auctions
    AuctionManager manager;
    manager.addAuction(auction1);
    manager.addAuction(auction2);

    manager.showAllAuctions();

    auction1.closeAuction();
    auction2.closeAuction();

    AuctionManager::showSummary();

    return 0;
}
