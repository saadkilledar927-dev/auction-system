#ifndef ITEM_H
#define ITEM_H

#include <string>
using namespace std;

class Item {
private:
    int itemId;
    string itemName;
    float basePrice;
    float currentBid;

    static int itemCount;   // shared across all Item objects

public:
    Item(string name, float basePrice);

    int getItemId() const;
    string getItemName() const;
    float getBasePrice() const;
    float getCurrentBid() const;
    void setCurrentBid(float bid);

    static int getItemCount();   // static member function
    void display() const;
};

#endif
